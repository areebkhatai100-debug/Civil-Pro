CIVIL MEASURE PRO - Free Android APK build

Is ZIP mein Android Studio project aur GitHub Actions workflow hai.

GitHub Actions par APK build karne ke liye:
1. GitHub account mein sign in karein: https://github.com
2. New repository banayein. Naam: CivilMeasurePro
3. ZIP ko pehle extract karein. ZIP ko as-is upload na karein.
4. Extracted CivilMeasurePro folder ke ANDAR ki sabhi files/folders
   repository ke root mein upload karein. .github folder bhi zaroor upload karein.
5. Repository ke Actions tab mein jaayein.
6. "Build Civil Measure Pro APK" workflow select karein.
7. "Run workflow" dabayein.
8. Build complete hone par run page ke Artifacts section se
   "Civil-Measure-Pro-APK" download karein.
9. Artifact ZIP extract karein; app-debug.apk ko install karein.

GitHub Actions ka free allowance aur plan limits apply honge.
Debug APK testing/install ke liye hai; Play Store release ke liye
signed release build alag se banana hoga.

package com.civilmeasurepro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.AnnotatedString
import java.util.Locale

data class MeasureUnit(val label: String, val symbol: String, val factor: Double, val offset: Double = 0.0)
data class MeasureCategory(val title: String, val hindi: String, val units: List<MeasureUnit>)

private val categories = listOf(
    MeasureCategory("Length", "लंबाई", listOf(
        MeasureUnit("Millimetre", "mm", .001), MeasureUnit("Centimetre", "cm", .01),
        MeasureUnit("Metre", "m", 1.0), MeasureUnit("Kilometre", "km", 1000.0),
        MeasureUnit("Inch", "in", .0254), MeasureUnit("Foot", "ft", .3048),
        MeasureUnit("Yard", "yd", .9144), MeasureUnit("Mile", "mi", 1609.344)
    )),
    MeasureCategory("Area", "क्षेत्रफल", listOf(
        MeasureUnit("Square millimetre", "mm²", .000001), MeasureUnit("Square centimetre", "cm²", .0001),
        MeasureUnit("Square metre", "m²", 1.0), MeasureUnit("Square kilometre", "km²", 1_000_000.0),
        MeasureUnit("Square foot", "ft²", .09290304), MeasureUnit("Square yard", "yd²", .83612736),
        MeasureUnit("Acre", "acre", 4046.8564224), MeasureUnit("Hectare", "ha", 10000.0)
    )),
    MeasureCategory("Volume", "आयतन", listOf(
        MeasureUnit("Cubic centimetre", "cm³", .000001), MeasureUnit("Cubic metre", "m³", 1.0),
        MeasureUnit("Litre", "L", .001), MeasureUnit("Millilitre", "mL", .000001),
        MeasureUnit("Cubic foot", "ft³", .0283168466), MeasureUnit("Cubic inch", "in³", .000016387064),
        MeasureUnit("US gallon", "US gal", .0037854118)
    )),
    MeasureCategory("Weight / Mass", "वजन", listOf(
        MeasureUnit("Milligram", "mg", .000001), MeasureUnit("Gram", "g", .001),
        MeasureUnit("Kilogram", "kg", 1.0), MeasureUnit("Tonne", "t", 1000.0),
        MeasureUnit("Pound", "lb", .45359237)
    )),
    MeasureCategory("Pressure", "दाब", listOf(
        MeasureUnit("Pascal", "Pa", 1.0), MeasureUnit("Kilopascal", "kPa", 1000.0),
        MeasureUnit("Megapascal", "MPa", 1_000_000.0), MeasureUnit("Bar", "bar", 100000.0),
        MeasureUnit("Atmosphere", "atm", 101325.0), MeasureUnit("PSI", "psi", 6894.757293)
    )),
    MeasureCategory("Speed", "गति", listOf(
        MeasureUnit("Metre per second", "m/s", 1.0), MeasureUnit("Kilometre per hour", "km/h", 1.0/3.6),
        MeasureUnit("Mile per hour", "mph", .44704)
    )),
    MeasureCategory("Angle", "कोण", listOf(
        MeasureUnit("Degree", "°", 1.0), MeasureUnit("Radian", "rad", 180.0/Math.PI),
        MeasureUnit("Gradian", "gon", .9)
    )),
    MeasureCategory("Temperature", "तापमान", listOf(
        MeasureUnit("Celsius", "°C", 1.0, 0.0),
        MeasureUnit("Fahrenheit", "°F", 5.0/9.0, -32.0*5.0/9.0),
        MeasureUnit("Kelvin", "K", 1.0, -273.15)
    ))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CivilMeasureApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CivilMeasureApp() {
    var categoryIndex by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("1") }
    var fromIndex by remember { mutableIntStateOf(0) }
    var toIndex by remember { mutableIntStateOf(1) }
    var fromExpanded by remember { mutableStateOf(false) }
    var toExpanded by remember { mutableStateOf(false) }
    val category = categories[categoryIndex]
    val clipboard = LocalClipboardManager.current
    val value = input.toDoubleOrNull()
    val result = if (value != null && value.isFinite()) {
        val base = value * category.units[fromIndex].factor + category.units[fromIndex].offset
        (base - category.units[toIndex].offset) / category.units[toIndex].factor
    } else null
    val navy = Color(0xFF101B35)
    val blue = Color(0xFF2864E8)
    val card = Color(0xFF1B2A49)

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF80A7FF), background = navy, surface = card,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17294B), Color(0xFF0B1224))))
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(16.dp), color = blue, modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Straighten, contentDescription = null, tint = Color.White)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("CIVIL MEASURE PRO", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("Smart Engineering Unit Converter", fontSize = 12.sp, color = Color(0xFFB8C8E8))
                    }
                    Text("v1.0", color = Color(0xFFB8C8E8), fontSize = 11.sp)
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20375F)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("MEASUREMENTS • माप", color = Color(0xFF9EBBFF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Convert units instantly", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("Civil engineering ke daily calculations, ek hi jagah.", color = Color(0xFFD2DDF4), fontSize = 13.sp)
                    }
                }

                Text("Select category  •  श्रेणी चुनें", color = Color(0xFFD9E4FF), fontWeight = FontWeight.SemiBold)
                var catExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = !catExpanded }) {
                    OutlinedTextField(
                        value = "${category.title}  •  ${category.hindi}",
                        onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                        colors = fieldColors()
                    )
                    ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                        categories.forEachIndexed { index, item ->
                            DropdownMenuItem(text = { Text("${item.title} • ${item.hindi}") }, onClick = {
                                categoryIndex = index; fromIndex = 0; toIndex = if (item.units.size > 1) 1 else 0
                                catExpanded = false
                            })
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Text("FROM  •  से", color = Color(0xFF9EBBFF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Enter value • मान डालें") },
                            singleLine = true, colors = fieldColors()
                        )
                        ExposedDropdownMenuBox(expanded = fromExpanded, onExpandedChange = { fromExpanded = !fromExpanded }) {
                            OutlinedTextField(
                                value = "${category.units[fromIndex].label} (${category.units[fromIndex].symbol})",
                                onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = fromExpanded) },
                                colors = fieldColors()
                            )
                            ExposedDropdownMenu(expanded = fromExpanded, onDismissRequest = { fromExpanded = false }) {
                                category.units.forEachIndexed { index, unit ->
                                    DropdownMenuItem(text = { Text("${unit.label} (${unit.symbol})") }, onClick = { fromIndex = index; fromExpanded = false })
                                }
                            }
                        }
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            FilledTonalIconButton(onClick = { val old = fromIndex; fromIndex = toIndex; toIndex = old }) {
                                Icon(Icons.Default.SwapVert, contentDescription = "Swap units")
                            }
                        }
                        Text("TO  •  में", color = Color(0xFF9EBBFF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        ExposedDropdownMenuBox(expanded = toExpanded, onExpandedChange = { toExpanded = !toExpanded }) {
                            OutlinedTextField(
                                value = "${category.units[toIndex].label} (${category.units[toIndex].symbol})",
                                onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = toExpanded) },
                                colors = fieldColors()
                            )
                            ExposedDropdownMenu(expanded = toExpanded, onDismissRequest = { toExpanded = false }) {
                                category.units.forEachIndexed { index, unit ->
                                    DropdownMenuItem(text = { Text("${unit.label} (${unit.symbol})") }, onClick = { toIndex = index; toExpanded = false })
                                }
                            }
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF244A82)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CONVERTED RESULT  •  परिणाम", color = Color(0xFFD0E0FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (result != null) {
                            Text(formatNumber(result), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                            Text("${category.units[toIndex].symbol}", color = Color(0xFFD0E0FF), fontSize = 16.sp)
                            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(formatNumber(result))) }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(7.dp))
                                Text("Copy result • कॉपी करें")
                            }
                        } else {
                            Text("Enter a valid number • सही संख्या डालें", color = Color.White, fontSize = 15.sp)
                        }
                    }
                }
                Text("Works offline • इंटरनेट के बिना भी काम करता है", color = Color(0xFF9EACCA), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Color(0xFF80A7FF), unfocusedBorderColor = Color(0xFF607397),
    focusedLabelColor = Color(0xFFB7CCFF), unfocusedLabelColor = Color(0xFFB7C5DE),
    cursorColor = Color(0xFF80A7FF), focusedContainerColor = Color(0xFF17243D),
    unfocusedContainerColor = Color(0xFF17243D)
)

private fun formatNumber(value: Double): String {
    if (!value.isFinite()) return "—"
    return String.format(Locale.US, "%.8f", value).replace(Regex("0+$"), "").replace(Regex("\\.$"), "").ifEmpty { "0" }
}
